// apps/selfstudy/frontend/app.js
// 자기주도학습 프론트엔드 메인 오케스트레이터 (SaaS 템플릿 표준 준수)

import { MQnetAuth } from '/shared/ui/auth.js?v=2.0';
import { state } from './js/state.js?v=2.0';
import {
  fetchStudyPlans, recordStudyProgress, fetchProgressLogs,
  askAiMentor, generateAiPlan, fetchStudyCafeSeat
} from './js/api.js?v=2.0';
import {
  renderStudyCafeSeatBadge, renderTimerDisplay, renderTasksList,
  renderAiChat, renderWeeklyReport
} from './js/ui.js?v=2.0';
import {
  showToast, openNewTaskModal, openAiPlanModal, openCurriculumModal, closeModal
} from './js/modals.js?v=2.0';

// ── DOM 캐싱 ─────────────────────────────────────────────
const scSeatBadgeEl   = document.getElementById('scSeatConnectionBadge');
const tasksListEl     = document.getElementById('tasksListContainer');
const aiChatEl        = document.getElementById('aiChatMessages');
const reportEl        = document.getElementById('reportContainer');
const aiInputEl       = document.getElementById('aiChatInput');
const btnAiSend       = document.getElementById('btnAiSend');
const timerCircleEl   = document.getElementById('timerCircle');

// ── 1. 스터디카페 연동 좌석 현황 갱신 ─────────────────────
async function checkStudyCafeSeat() {
  const user = state.currentUser;
  if (!user) {
    state.studycafeSeat.hasSeat = false;
    renderStudyCafeSeatBadge(scSeatBadgeEl, state.studycafeSeat);
    return;
  }

  try {
    const res = await fetchStudyCafeSeat(user.id, user.phone, user.full_name);
    if (res && res.has_seat && res.seat) {
      state.studycafeSeat = {
        hasSeat: true,
        seatNumber: res.seat.seat_number,
        zoneType: res.seat.zone_type,
        userType: res.seat.user_type,
        checkInAt: res.seat.check_in_at
      };
    } else {
      state.studycafeSeat.hasSeat = false;
    }
  } catch (e) {
    state.studycafeSeat.hasSeat = false;
  }
  renderStudyCafeSeatBadge(scSeatBadgeEl, state.studycafeSeat);
}

// ── 2. 타이머 로직 ───────────────────────────────────────
function setupTimer() {
  const btnStart = document.getElementById('btnTimerStart');
  const btnReset = document.getElementById('btnTimerReset');
  const btnFinish = document.getElementById('btnTimerFinish');
  const btnPomo = document.getElementById('btnModePomodoro');
  const btnStopwatch = document.getElementById('btnModeStopwatch');

  btnPomo?.addEventListener('click', () => {
    if (state.timer.isRunning) return;
    state.timer.mode = 'pomodoro';
    btnPomo.classList.add('active');
    btnStopwatch.classList.remove('active');
    state.timer.remainingSeconds = state.timer.pomodoroInitialSeconds;
    renderTimerDisplay(state.timer);
  });

  btnStopwatch?.addEventListener('click', () => {
    if (state.timer.isRunning) return;
    state.timer.mode = 'stopwatch';
    btnStopwatch.classList.add('active');
    btnPomo.classList.remove('active');
    state.timer.elapsedSeconds = 0;
    renderTimerDisplay(state.timer);
  });

  btnStart?.addEventListener('click', () => {
    if (state.timer.isRunning) {
      // 일시정지
      clearInterval(state.timer.intervalId);
      state.timer.isRunning = false;
      timerCircleEl?.classList.remove('running');
      renderTimerDisplay(state.timer);
    } else {
      // 시작
      state.timer.isRunning = true;
      timerCircleEl?.classList.add('running');
      state.timer.intervalId = setInterval(onTimerTick, 1000);
      renderTimerDisplay(state.timer);
      showToast('🔥 집중 학습이 시작되었습니다. 파이팅!', 'info', 2000);
    }
  });

  btnReset?.addEventListener('click', () => {
    clearInterval(state.timer.intervalId);
    state.timer.isRunning = false;
    timerCircleEl?.classList.remove('running');
    if (state.timer.mode === 'pomodoro') {
      state.timer.remainingSeconds = state.timer.pomodoroInitialSeconds;
    } else {
      state.timer.elapsedSeconds = 0;
    }
    renderTimerDisplay(state.timer);
  });

  btnFinish?.addEventListener('click', async () => {
    const elapsed = state.timer.mode === 'pomodoro' 
      ? (state.timer.pomodoroInitialSeconds - state.timer.remainingSeconds)
      : state.timer.elapsedSeconds;

    const studiedMinutes = Math.max(1, Math.round(elapsed / 60));
    try {
      await recordStudyProgress(studiedMinutes, ['집중 세션 완료']);
      state.timer.todayFocusSeconds += elapsed;
      showToast(`🎉 ${studiedMinutes}분 순공 시간이 저장되었습니다!`, 'success');
      btnReset.click();
    } catch (e) {
      showToast(e.message, 'error');
    }
  });
}

function onTimerTick() {
  if (state.timer.mode === 'pomodoro') {
    if (state.timer.remainingSeconds > 0) {
      state.timer.remainingSeconds -= 1;
      state.timer.todayFocusSeconds += 1;
    } else {
      // 뽀모도로 완료
      clearInterval(state.timer.intervalId);
      state.timer.isRunning = false;
      timerCircleEl?.classList.remove('running');
      showToast('🔔 25분 뽀모도로 집중 완료! 5분간 뇌를 쉬어주세요.', 'success', 5000);
    }
  } else {
    state.timer.elapsedSeconds += 1;
    state.timer.todayFocusSeconds += 1;
  }
  renderTimerDisplay(state.timer);
}

// ── 3. 과목 플래너 로직 ───────────────────────────────────
function setupPlanner() {
  const btnOpenTaskModal = document.getElementById('btnOpenTaskModal');
  const btnOpenAiPlanModal = document.getElementById('btnOpenAiPlanModal');
  const btnOpenCurriculumModal = document.getElementById('btnOpenCurriculumModal');

  function renderCurriculumSummary() {
    const summaryBar = document.getElementById('curriculumSummaryBar');
    if (!summaryBar) return;
    if (state.curriculum) {
      summaryBar.style.display = 'flex';
      const weeklyH = Object.values(state.curriculum.weeklySchedule || {}).reduce((a, b) => a + b, 0);
      summaryBar.innerHTML = `
        <div class="curr-summary-left">
          <span class="curr-summary-badge">D-${state.curriculum.totalDays || 30} 진도 진행 중</span>
          <strong>목표 완주 D-day: ${state.curriculum.endDate}</strong>
          <span style="font-size:0.8rem;color:var(--text-muted);">(5개 과목 등록됨)</span>
        </div>
        <div class="curr-summary-right">
          <span>주당 학습: <strong>${weeklyH}시간</strong></span>
          <button id="btnEditCurrMini" class="btn-timer-secondary" style="padding:0.25rem 0.6rem;font-size:0.75rem;border-radius:6px" type="button">진도 수정 ⚙️</button>
        </div>
      `;
      document.getElementById('btnEditCurrMini')?.addEventListener('click', () => {
        openCurriculumModal(handleSaveCurriculum, state.curriculum);
      });
    } else {
      summaryBar.style.display = 'none';
    }
  }

  function handleSaveCurriculum(currData) {
    state.curriculum = currData;
    localStorage.setItem('mqnet_selfstudy_curriculum', JSON.stringify(currData));

    // 오늘 1일차 오더로 과목 플래너 목록 자동 교체
    if (currData.todayOrders && currData.todayOrders.length > 0) {
      state.tasks = currData.todayOrders.map((o, idx) => ({
        id: Date.now() + idx,
        subject: o.subject,
        bookName: o.bookName || `${o.subject} 기본서`,
        startPage: o.startPage,
        goalPage: o.todayGoalPage,
        dailyPages: o.dailyPages,
        completedPage: null,
        title: `${o.subject} [${o.startPage}p ➔ ${o.todayGoalPage}p] (+${o.dailyPages}p 완독 목표)`,
        done: false,
        minutes: o.minutes || 48
      }));
      localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
    }

    renderCurriculumSummary();
    renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
  }

  btnOpenCurriculumModal?.addEventListener('click', () => {
    openCurriculumModal(handleSaveCurriculum, state.curriculum);
  });

  btnOpenTaskModal?.addEventListener('click', () => {
    openNewTaskModal((newTask) => {
      state.tasks.push({
        id: Date.now(),
        subject: newTask.subject,
        title: newTask.title,
        done: false,
        minutes: newTask.minutes
      });
      localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
      renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
    });
  });

  btnOpenAiPlanModal?.addEventListener('click', () => {
    openAiPlanModal(async ({ subject, target, dailyMinutes }) => {
      const res = await generateAiPlan(subject, target, dailyMinutes);
      showToast('✨ Gemini AI 맞춤 플랜이 생성되었습니다!', 'success');
      
      // AI 플랜을 과제 목록에 자동 추가
      if (res && res.ai_plan) {
        state.tasks.push({
          id: Date.now(),
          subject: subject,
          title: `[AI 추천] ${target}`,
          done: false,
          minutes: dailyMinutes
        });
        localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
        renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
      }
    });
  });

  renderCurriculumSummary();
  renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
}

function handleRecordTaskProgress(taskId, completedPage) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  if (completedPage == null) {
    task.completedPage = null;
    task.done = false;
    task.pph = null;
  } else {
    task.completedPage = completedPage;
    task.done = completedPage >= task.goalPage;
    const actualPages = Math.max(0, completedPage - task.startPage + 1);
    task.pph = task.minutes > 0 ? ((actualPages / (task.minutes / 60))).toFixed(1) : null;

    if (completedPage > task.goalPage) {
      showToast(`🚀 [${task.subject}] ${completedPage}p 도달! 목표 초과 달성 (+${completedPage - task.goalPage}p)`, 'success');
    } else if (completedPage === task.goalPage) {
      showToast(`🎉 [${task.subject}] ${completedPage}p 완독! 오늘 목표 100% 달성`, 'success');
    } else {
      showToast(`⚠️ [${task.subject}] ${completedPage}p 기록 완료 (${task.goalPage - completedPage}p 미달은 익일 진도로 이월)`, 'warning');
    }
  }

  localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
  renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
}

function handleToggleTask(taskId, isDone) {
  const task = state.tasks.find(t => t.id === taskId);
  if (task) {
    task.done = isDone;
    localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
    renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
  }
}

function handleDeleteTask(taskId) {
  state.tasks = state.tasks.filter(t => t.id !== taskId);
  localStorage.setItem('mqnet_selfstudy_tasks', JSON.stringify(state.tasks));
  renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask, handleRecordTaskProgress);
  showToast('과제가 삭제되었습니다.', 'info', 1500);
}

// ── 4. AI 멘토 채팅 로직 ──────────────────────────────────
function setupAiMentor() {
  renderAiChat(aiChatEl, state.aiChat);

  const sendMessage = async (text) => {
    if (!text) return;
    const nowStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });

    // 유저 메시지 추가
    state.aiChat.push({
      id: Date.now(),
      sender: 'user',
      text,
      time: nowStr
    });
    renderAiChat(aiChatEl, state.aiChat);
    aiInputEl.value = '';

    // 임시 AI 답변 대기 표시
    const pendingId = Date.now() + 1;
    state.aiChat.push({
      id: pendingId,
      sender: 'ai',
      text: '생각 중입니다... ✍️',
      time: nowStr
    });
    renderAiChat(aiChatEl, state.aiChat);

    try {
      const res = await askAiMentor(text);
      const aiReply = (res && res.reply) || (res && res.message) || '좋은 질문입니다! 꾸준한 학습 루틴이 성과의 핵심입니다.';
      
      // 답변 갱신
      const pendingMsg = state.aiChat.find(m => m.id === pendingId);
      if (pendingMsg) {
        pendingMsg.text = aiReply;
      }
    } catch (e) {
      const pendingMsg = state.aiChat.find(m => m.id === pendingId);
      if (pendingMsg) {
        pendingMsg.text = '학습 목표 달성을 위해 한 걸음씩 차근차근 나아가세요! 제가 항상 곁에서 돕겠습니다.';
      }
    }
    renderAiChat(aiChatEl, state.aiChat);
  };

  btnAiSend?.addEventListener('click', () => {
    sendMessage(aiInputEl.value.trim());
  });

  aiInputEl?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      sendMessage(aiInputEl.value.trim());
    }
  });

  // 퀵 칩 버튼들 바인딩
  document.querySelectorAll('.quick-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.q;
      if (q) sendMessage(q);
    });
  });
}

// ── 5. 리포트 렌더링 ──────────────────────────────────────
function renderReport() {
  renderWeeklyReport(reportEl);
}

// ── 6. 탭 전환 ───────────────────────────────────────────
function switchTab(tabId) {
  state.activeTab = tabId;

  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });

  const sections = {
    timer: document.getElementById('tabTimer'),
    planner: document.getElementById('tabPlanner'),
    ai: document.getElementById('tabAi'),
    report: document.getElementById('tabReport')
  };

  Object.keys(sections).forEach(key => {
    if (sections[key]) {
      sections[key].style.display = (key === tabId) ? 'block' : 'none';
    }
  });

  if (tabId === 'timer') renderTimerDisplay(state.timer);
  else if (tabId === 'planner') renderTasksList(tasksListEl, state.tasks, handleToggleTask, handleDeleteTask);
  else if (tabId === 'ai') renderAiChat(aiChatEl, state.aiChat);
  else if (tabId === 'report') renderReport();
}

// ── 7. 초기화 ─────────────────────────────────────────────
async function init() {
  // 🔑 MQnet 통합 인증 초기화 및 배지 부착
  MQnetAuth.init({
    appId: 'selfstudy',
    autoPrompt: true,
    onAuthChange: (user) => {
      state.currentUser = user;
      checkStudyCafeSeat();
    }
  });
  MQnetAuth.renderBadge('userAuthBadge');

  state.currentUser = MQnetAuth.getUser();

  // 탭 클릭 바인딩
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      switchTab(btn.dataset.tab);
    });
  });

  setupTimer();
  setupPlanner();
  setupAiMentor();
  renderReport();

  await checkStudyCafeSeat();
  renderTimerDisplay(state.timer);
}

init();
