/**
 * apps/rent/frontend/js/seed_data.js
 * 29개실 표준 공인 장부 시드 데이터 (구글 시트 2025.12 ~ 2026.10 완벽 동기화)
 */
export const CANONICAL_ROOMS_DATA = {
  "101": {
    "room_number": 101,
    "number": 101,
    "name": "배종봉",
    "rent": 150000,
    "maintenance": 100000,
    "deposit": 2000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-5424-5780",
    "id_number": "701127-1520023",
    "move_in": "2025-06-04",
    "expiry": "2026-12-10",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "배종봉"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입6/3",
        "tenant_name": "배종봉"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입6/3",
        "tenant_name": "배종봉"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-03",
        "rent_amount": 250000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-03",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 150000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배종봉"
      }
    }
  },
  "201": {
    "room_number": 201,
    "number": 201,
    "name": "정민준",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-5578-5358",
    "id_number": "921013-1025438",
    "move_in": "2022-03-19",
    "expiry": "2026-12-12",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-19",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-19",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-29",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-29",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "정민준"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-21",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-21",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-21",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-21",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정민준"
      }
    }
  },
  "202": {
    "room_number": 202,
    "number": 202,
    "name": "안동기",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 3000000,
    "lease_type": "월세",
    "pay_timing": "선불",
    "phone": "010-9429-4688",
    "id_number": "701110-1814911",
    "move_in": "2015-04-10",
    "expiry": "2027-04-10",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "안동기"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "안동기"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "안동기"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "안동기"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "안동기"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2026-01-29",
        "rent_amount": 1610000,
        "maintenance_amount": 150000,
        "note": "선납 4개월",
        "tenant_name": "안동기"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "안동기"
      }
    }
  },
  "203": {
    "room_number": 203,
    "number": 203,
    "name": "이광훈",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8417-7858",
    "id_number": "580115-1268113",
    "move_in": "2024-08-01",
    "expiry": "2027-07-31",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-35",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이광훈"
      }
    }
  },
  "204": {
    "room_number": 204,
    "number": 204,
    "name": "주예란",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8982-8146",
    "id_number": "770925-2169514",
    "move_in": "2021-06-05",
    "expiry": "2027-06-04",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주예란"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "주예란"
      }
    }
  },
  "205": {
    "room_number": 205,
    "number": 205,
    "name": "서재민",
    "rent": 250000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-4947-8994",
    "id_number": "980706-1122013",
    "move_in": "2024-01-27",
    "expiry": "2027-01-26",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-25",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-25",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-21",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-21",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-23",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-22",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-20",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-25",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "서재민"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-20",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-20",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-20",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-21",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-22",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "서재민"
      }
    }
  },
  "301": {
    "room_number": 301,
    "number": 301,
    "name": "성민병원",
    "rent": 390000,
    "maintenance": 50000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-9938-6293",
    "id_number": "124233-0000347",
    "move_in": "2022-03-28",
    "expiry": "2027-03-27",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 390000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "성민병원"
      }
    }
  },
  "302": {
    "room_number": 302,
    "number": 302,
    "name": "김지영",
    "rent": 0,
    "maintenance": 150000,
    "deposit": 40000000,
    "lease_type": "전세",
    "pay_timing": "후불",
    "phone": "010-2668-9764",
    "id_number": "690120-2150013",
    "move_in": "2019-03-21",
    "expiry": "2027-03-20",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-19",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-19",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-16",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-16",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-17",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-17",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-16",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-16",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-27",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-27",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-17",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-17",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-20",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-20",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-21",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-21",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-18",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-18",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-21",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-21",
        "rent_amount": 150000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김지영"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-21",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-17",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-17",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-17",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-18",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김지영"
      }
    }
  },
  "303": {
    "room_number": 303,
    "number": 303,
    "name": "김진수",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-9169-0757",
    "id_number": "960617-1479024",
    "move_in": "2025-09-12",
    "expiry": "2027-09-11",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-06",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-06",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-25",
        "rent_amount": 500000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김진수"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입9/13",
        "tenant_name": "김진수"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입9/13",
        "tenant_name": "김진수"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-12",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김진수"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-12",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김진수"
      }
    }
  },
  "304": {
    "room_number": 304,
    "number": 304,
    "name": "노송병원",
    "rent": 340000,
    "maintenance": 50000,
    "deposit": 10000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-4293-5511",
    "id_number": "137-91-92800",
    "move_in": "2022-05-01",
    "expiry": "2027-04-30",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-02",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-01",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-03",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-08",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-08",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-08",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-08",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-20",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-20",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-20",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-03",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-02",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 340000,
        "maintenance_amount": 50000,
        "note": "",
        "tenant_name": "노송병원"
      }
    }
  },
  "305": {
    "room_number": 305,
    "number": 305,
    "name": "김인식",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 3000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-9026-2596",
    "id_number": "137-14-88402",
    "move_in": "2023-04-13",
    "expiry": "2027-04-12",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-16",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-16",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-18",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-18",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김인석"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김인식"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정우메탈"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정우메탈"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정우메탈"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "정우메탈"
      }
    }
  },
  "401": {
    "room_number": 401,
    "number": 401,
    "name": "이정도",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-2763-7108",
    "id_number": "521010-1231421",
    "move_in": "2023-04-09",
    "expiry": "2027-04-08",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-14",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이정도"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이정도"
      }
    }
  },
  "402": {
    "room_number": 402,
    "number": 402,
    "name": "한운철",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 3000000,
    "lease_type": "월세",
    "pay_timing": "선불",
    "phone": "010-9279-7975",
    "id_number": "760813-1156821",
    "move_in": "2024-02-28",
    "expiry": "2027-02-28",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-29",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-29",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한운철"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한윤철"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한윤철"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한윤철"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "한윤철"
      }
    }
  },
  "403": {
    "room_number": 403,
    "number": 403,
    "name": "김정두",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-3132-2713",
    "id_number": "910905-1125625",
    "move_in": "2025-12-19",
    "expiry": "2026-12-18",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-11",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-11",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정두"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김정두"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "김정두"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입 12/19",
        "tenant_name": "김정두"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정두"
      }
    }
  },
  "404": {
    "room_number": 404,
    "number": 404,
    "name": "이종진",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-4808-9078",
    "id_number": "670219-1251211",
    "move_in": "2026-07-01",
    "expiry": "2027-06-07",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이종진"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출6/4",
        "tenant_name": "이종진"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출6/4",
        "tenant_name": "이종진"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출6/4",
        "tenant_name": "이종진"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-07",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-06",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-06",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이종진"
      }
    }
  },
  "405": {
    "room_number": 405,
    "number": 405,
    "name": "김병현",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-7170-8629",
    "id_number": "880107-1168012",
    "move_in": "2026-04-01",
    "expiry": "2027-03-08",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-28",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-28",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-31",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-31",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "김병현"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "미납",
        "tenant_name": "김병현"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "5/26 전입",
        "tenant_name": "김병현"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "5/26 전입",
        "tenant_name": "김병현"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-25",
        "rent_amount": 450000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김병현"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 300000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출3/2",
        "tenant_name": "김병현"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출3/2",
        "tenant_name": "김병현"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전출3/2",
        "tenant_name": "김병현"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-09",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-09",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-09",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-08",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-05",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-05",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-05",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-05",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-05",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김병현"
      }
    }
  },
  "501": {
    "room_number": 501,
    "number": 501,
    "name": "김민규",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-3528-9240",
    "id_number": "960426-1860829",
    "move_in": "2024-08-30",
    "expiry": "2027-08-31",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-31",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-30",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김민규"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-31",
        "rent_amount": 350000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-31",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-30",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김민규"
      }
    }
  },
  "502": {
    "room_number": 502,
    "number": 502,
    "name": "강흥식",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "반선불",
    "phone": "010-6605-5279",
    "id_number": "800629-1223315",
    "move_in": "2023-02-01",
    "expiry": "2027-02-01",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강흥식"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강홍식"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강홍식"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강홍식"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강홍식"
      }
    }
  },
  "503": {
    "room_number": 503,
    "number": 503,
    "name": "강백찬",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8864-2674",
    "id_number": "020507-3937718",
    "move_in": "2026-09-01",
    "expiry": "2027-09-29",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-26",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-26",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-26",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-30",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-30",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 340000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 340000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-18",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-20",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-22",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 160000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 160000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 160000,
        "note": "",
        "tenant_name": "강백찬"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 160000,
        "note": "",
        "tenant_name": "강백찬"
      }
    }
  },
  "504": {
    "room_number": 504,
    "number": 504,
    "name": "이수현",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-5059-2191",
    "id_number": "910607-1183615",
    "move_in": "2025-04-01",
    "expiry": "2027-03-31",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-10",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입4/1",
        "tenant_name": "이수현"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입4/1",
        "tenant_name": "이수현"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이수현"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-19",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "이수현"
      }
    }
  },
  "505": {
    "room_number": 505,
    "number": 505,
    "name": "김정현",
    "rent": 250000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "선불",
    "phone": "010-9810-0443",
    "id_number": "981001-1338617",
    "move_in": "2026-07-01",
    "expiry": "2027-06-28",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-14",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-14",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-14",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-14",
        "rent_amount": 350000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입4/1",
        "tenant_name": "김정현"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입4/1",
        "tenant_name": "김정현"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-01",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-01",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-01",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-01",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-26",
        "rent_amount": 400000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김정현"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "전출6/26",
        "tenant_name": "김정현"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "전출6/26",
        "tenant_name": "김정현"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "전출6/26",
        "tenant_name": "김정현"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-29",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-29",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-29",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-17",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-17",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-17",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김정현"
      }
    }
  },
  "601": {
    "room_number": 601,
    "number": 601,
    "name": "노무영",
    "rent": 350000,
    "maintenance": 90000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8764-0958",
    "id_number": "710719-1538528",
    "move_in": "2024-09-23",
    "expiry": "2027-09-22",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "노우영"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노무영"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노우영"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노우영"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노우영"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 350000,
        "maintenance_amount": 90000,
        "note": "",
        "tenant_name": "노우영"
      }
    }
  },
  "602": {
    "room_number": 602,
    "number": 602,
    "name": "박정자",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8025-8400",
    "id_number": "560210-2005915",
    "move_in": "2014-06-02",
    "expiry": "2027-06-02",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-04",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-02",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-01",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-03",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "박정자"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-03",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-04",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-02",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-01",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "박정자"
      }
    }
  },
  "603": {
    "room_number": 603,
    "number": 603,
    "name": "김수현",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-9277-9233",
    "id_number": "921203-1235714",
    "move_in": "2025-07-27",
    "expiry": "2027-07-26",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-21",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-20",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입",
        "tenant_name": "김수현"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입",
        "tenant_name": "김수현"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-27",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-28",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김수현"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-28",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-27",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김수현"
      }
    }
  },
  "604": {
    "room_number": 604,
    "number": 604,
    "name": "김동주",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-7709-8970",
    "id_number": "990913-1155417",
    "move_in": "2024-04-16",
    "expiry": "2027-04-15",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-12",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-12",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-11",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-11",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-09",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-15",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김동주"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-13",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-16",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-15",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-14",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김동주"
      }
    }
  },
  "605": {
    "room_number": 605,
    "number": 605,
    "name": "배은미",
    "rent": 290000,
    "maintenance": 100000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-7367-0187",
    "id_number": "960124-2157011",
    "move_in": "2024-05-26",
    "expiry": "2027-05-26",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-26",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-25",
        "rent_amount": 390000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "배은미"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-25",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-26",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 100000,
        "note": "",
        "tenant_name": "배은미"
      }
    }
  },
  "701": {
    "room_number": 701,
    "number": 701,
    "name": "주인세대",
    "rent": 0,
    "maintenance": 0,
    "deposit": 0,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "",
    "id_number": "",
    "move_in": "",
    "expiry": "",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "공실",
        "tenant_name": "공실"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "주인세대"
      }
    }
  },
  "702": {
    "room_number": 702,
    "number": 702,
    "name": "이범주",
    "rent": 290000,
    "maintenance": 250000,
    "deposit": 6000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-5749-1106",
    "id_number": "901106-1158022",
    "move_in": "2024-04-05",
    "expiry": "2027-04-04",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-01-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-06",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-05",
        "rent_amount": 540000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "이범주"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-01-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-06",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-10-05",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 250000,
        "note": "",
        "tenant_name": "이범주"
      }
    }
  },
  "703": {
    "room_number": 703,
    "number": 703,
    "name": "김상호",
    "rent": 290000,
    "maintenance": 150000,
    "deposit": 5000000,
    "lease_type": "월세",
    "pay_timing": "후불",
    "phone": "010-8212-9257",
    "id_number": "570709-1006015",
    "move_in": "2026-02-01",
    "expiry": "2027-01-22",
    "move_out": "",
    "payments": {
      "2025-1": {
        "month": 1,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입 1/17",
        "tenant_name": "김상호"
      },
      "2025-01": {
        "month": 1,
        "year": 2025,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "전입 1/17",
        "tenant_name": "김상호"
      },
      "2025-2": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-02": {
        "month": 2,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-02-17",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-3": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-19",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-03": {
        "month": 3,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-03-19",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-4": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-04": {
        "month": 4,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-04-13",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-5": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-05": {
        "month": 5,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-05-23",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-6": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-06": {
        "month": 6,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-06-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-7": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-07": {
        "month": 7,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-07-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-8": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-08": {
        "month": 8,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-08-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-9": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-09": {
        "month": 9,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-09-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-10": {
        "month": 10,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-10-24",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-11": {
        "month": 11,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-11-25",
        "rent_amount": 440000,
        "maintenance_amount": 0,
        "note": "",
        "tenant_name": "김상호"
      },
      "2025-12": {
        "month": 12,
        "year": 2025,
        "paid": true,
        "paid_date": "2025-12-06",
        "rent_amount": 250000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-1": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "1/23전입",
        "tenant_name": "김상호"
      },
      "2026-01": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "1/23전입",
        "tenant_name": "김상호"
      },
      "1": {
        "month": 1,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 0,
        "maintenance_amount": 0,
        "note": "1/23전입",
        "tenant_name": "김상호"
      },
      "2026-2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-02": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2": {
        "month": 2,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-02-24",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-03": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "3": {
        "month": 3,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-03-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-04": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "4": {
        "month": 4,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-04-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-05": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "5": {
        "month": 5,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-05-26",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-06": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "6": {
        "month": 6,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-06-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-07": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "7": {
        "month": 7,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-07-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-08": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "8": {
        "month": 8,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-08-25",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-09": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "9": {
        "month": 9,
        "year": 2026,
        "paid": true,
        "paid_date": "2026-09-23",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "10": {
        "month": 10,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "11": {
        "month": 11,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "2026-12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      },
      "12": {
        "month": 12,
        "year": 2026,
        "paid": false,
        "paid_date": "",
        "rent_amount": 290000,
        "maintenance_amount": 150000,
        "note": "",
        "tenant_name": "김상호"
      }
    }
  }
};
