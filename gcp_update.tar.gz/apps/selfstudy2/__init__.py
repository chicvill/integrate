"""selfstudy2 package"""
